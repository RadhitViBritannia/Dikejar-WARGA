<div class="container">
    <h4 class="text-center mt-3">Uji Kompetensi Keahlian <br>Rekayasa Perangkat Lunak (RPL) <br> Tahun 2022/2023</h4>
    <hr>
    <div class="row mt-3">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">INFORMASI</div>
                <div class="card-body">
                    Aplikasi pengaduan masyarakat ini dibuat untuk memenuhi tugas Ujian Kompetensi Keahlian RPL Tahun 2023 <br></br> Petunjuk Penggunaan Aplikasi :
                </div>
                <div class="card-footer"></div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">KONTAK</div>
                <div class="card-body">
                    Dikembangkan oleh <br>
                    Nama Peserta : <br>
                    Kelas : Kelas Berapa <br>
                    No.HP : Berapa <br>
                </div>
                <div class="card-footer"></div>
            </div>
        </div>
    </div>
</div>